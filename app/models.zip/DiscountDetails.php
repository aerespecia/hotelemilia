<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DiscountDetails extends Model
{
    //
    protected $fillable = [
    'name',
    'type',
    'discountValue',
    'logs'];
}
