<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    //
    protected $fillable = [
    'code',
    'clientId',
    'type',
    'packageId',
    'status',
    'chargeType',
    'madeThru',
    'billingType',
    'billingNote',
    'guaranteed',
    'guaranteedNote',
    'specialRequest',
    'logs'];
}
