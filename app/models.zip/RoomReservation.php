<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoomReservation extends Model
{
    //
    protected $fillable = [
    'transactionId',
    'roomId',
    'arrivalDate',
    'depatureDate',
    'discountId',
    'type',
    'status',
    'reserveType',
    'extensionDate',
    'logs'];
}
