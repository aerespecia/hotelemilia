

	{!! Form::open(['method'=>'POST','action'=>'FrontDeskController@saveMe','name'=>'formregis']) !!}

	<input type="text" name="henry" />
	<input type="submit" value="Henry's Button"/>
	

	{!! Form::close() !!}

