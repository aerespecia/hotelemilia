<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PerksItem extends Model
{
    //
    protected $fillable = [
    'groupId',
    'itemId',
    'logs'];
}
