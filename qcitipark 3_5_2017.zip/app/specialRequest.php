<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class specialRequest extends Model
{
    //
}
