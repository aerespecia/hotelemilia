@extends('layouts.frontdeskLayout')

@section('content')
 
<div class="main-content">
        <!-- BEGIN TOPBAR -->
        <div class="topbar" style="background-color:white;">
          <div class="header-left">
            <div class="topnav">
            
              <ul class="nav nav-tabs no-border">
                <li><a href="{{route('frontdesk.index')}}"><i class="fa fa-calendar-o"></i><span>Rooms</span></a></li>
                <li><a href="{{route('frontdesk.reservation')}}"><i class="fa fa-calendar-o"></i><span>Reservations</span></a></li>
               <li><a href="{{route('frontdesk.guestRegistration')}}"><i class="fa fa-users"></i><span>Bookings</span></a></li>
              
                <li class="nav-active active"><a href="{{route('frontdesk.nightAudit')}}"><i class="icon-note"></i><span>Night Audit</span></a></li>
               
                   <li><a href="{{route('frontdesk.roomissue')}}"><i class="icon-note"></i><span>Issues</span></a></li>
              </ul>
            </div>
          </div>
          <div class="header-right">
            <ul class="header-menu nav navbar-nav">
              <!-- BEGIN USER DROPDOWN -->
               
          
           
              
            
              
              <!-- END USER DROPDOWN -->
              <!-- BEGIN NOTIFICATION DROPDOWN -->
            
              <!-- END NOTIFICATION DROPDOWN -->
              <!-- BEGIN MESSAGES DROPDOWN -->
              
              <!-- END MESSAGES DROPDOWN -->
              <!-- BEGIN USER DROPDOWN -->
              <li class="dropdown" id="user-header">
                <a href="#" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                <img src="{{url('assets/global/images/avatars/avatar11_big.png')}}" alt="user image">
                <span class="username">Hi, {{$user->name}}</span>
                </a>
                <ul class="dropdown-menu">
                  
                  <li>
                    <a href="{{url('/logout')}}"><i class="icon-logout"></i><span>Logout</span></a>
                  </li>
                </ul>
              </li>
              <!-- END USER DROPDOWN -->
              <!-- CHAT BAR ICON -->
             
            </ul>
          </div>
          <!-- header-right -->
        </div>
        <!-- END TOPBAR -->
        <!-- BEGIN PAGE CONTENT -->
        <div class="page-content p-l-25 p-r-20 p-t-10">
            
            <div class="btn-group">
  
             
    </div>


    <script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>
            <hr class="m-t-5 c-red"/>
          <div class="panel-header">
            <h2><strong>NIGH AUDIT</strong></h2>
              {!! Form::open(['method'=>'GET','action'=>'FrontDeskController@nightAudit','name'=>'formregis','id'=>'FrontDeskController','class'=>'wizard','data-style'=>'simple']) !!}
                  <div class="row">
                      <div class="col-md-3 m-t-10">
                      <div class="prepend-icon">
                      <input type="text" id="date-main" name="date-main" autocomplete="off" class="b-datepicker form-control" placeholder="Select a date..." data-orientation="top">
                      <i class="icon-calendar"></i>
                    </div>
                          
                      </div>
                    <div class="col-md-1 m-t-10">
                         <input type="submit" class="btn btn-primary" value="Search"/>  
                    </div>
                 </div>
                {!! Form::close() !!}
                   
                    <h4><strong>Date:</strong> <span class="c-red"><strong>{{$date}}</strong></span></h4>
               
              
          </div>
            <?php $occupiedRoomsTotal = 0; 
                  $arrivalTotal = 0;
                  $stayingTotal = 0;
                  $departureTotal = 0;
            ?>
             
            
           <div class="panel">
               <div class="panel-header">
          
       <?php $transactionsIDA = array(); 
             $transactionsIDS = array();
             $transactionsIDD = array();
       ?>
               </div>
            <div class="panel-content">
                <div class="row">
            <div class="col-md-12">
                <div class="nav-tabs2">
                        <ul class="nav nav-tabs nav-red">
                          <li class="active"><a href="#tab5_1" data-toggle="tab"> ARRIVALS</a></li>
                          <li><a href="#tab5_2" data-toggle="tab">STAYING</a></li>
                          <li><a href="#tab5_3" data-toggle="tab">DEPARTURES</a></li>
                        </ul>
                        <div class="tab-content">
                          <div class="tab-pane active" id="tab5_1">
                          
                 <div class="panel">
                  <div class="panel-header bg-dark">
                    <h3><strong>Reservations:</strong></h3>
             
                  </div>

                  <div class="panel-content" style="overflow-y: scroll; height:500px;">
                         @foreach($transactions as $t)
                  @if($t->arrivalDate == $dateMain)
                    <?php $totalCharges = 0;
                          $totalPayments = 0;

                     ?>

           
                <table id="transactionTables" class="table table-bordered bg-white">
            
                  <thead class="f-13 bg-dark">
                    <tr>
                      <th colspan="3" class="bg-blue">Code: <strong>{{$t->code}}</strong></th>
                      <th colspan="2" class="bg-blue">Rooms:</th>
                      <th class="bg-blue">Status:</th>
                    </tr>
                  </thead>
                  <tbody class="f-12">
                    <tr>
                      <td colspan="3">
                        <ul style="list-style: none;">
                          <li>Institution: <strong>{{$t->institutionName.' ('.$t->accountName}})</strong></li>
                          <li>Booking Person: <strong>{{$t->bookingPerson}}</strong></li>
                        </ul>
                        
                      </td>
                      <td colspan="2" valign="top">
                        <ul style="margin-left:20px;">
                          @foreach($roomsIn as $ra)
                          @if($ra->transID == $t->id and !in_array($t->id,$transactionsIDA))
                              <li>{{$ra->roomNo.' ('.$ra->roomType}})</li>
                          @endif
                          @endforeach
                        </ul>
                         
                      </td>
                      <td>
                        <ul style="list-style: none;">
                        @if($t->transactionStatus == 0)
                          <li><span class="label label-success">Ongoing</span></li>
                        @elseif($t->transactionStatus ==1)
                          <li><span class="label label-danger">Billed</span></li>
                        @elseif($t->transactionStatus == 2)
                          <li><span class="label label-dark">No Show</span></li>
                        @elseif($t->transactionStatus == 3)
                          <li><span class="label label-blue">House Use</span></li>
                        @elseif($t->transactionStatus == 100)
                          <li><span class="label label-danger">Fully Paid</span></li>
                        @elseif($t->transactionStatus == 1000)
                          <li><span class="label label-dark">Partial Payment</span></li>
                        @endif


                        @if($t->guaranteed == 1)
                          <li><span class="label label-warning">Guaranteed</span></li>
                        @elseif($t->guaranteed == 2)
                          <li><span class="label label-default">Not Guaranteed</span></li>
                        @endif 
                        </ul>
                      </td>
                    </tr>
                  </tbody>
                <thead class="f-12">
                      <tr>
                        <th>OS/OR No.</th>
                        <th>Particulars</th>
                        <th>Charges</th>
                        <th>Payments</th>
                        <th>Paid thru</th>
                        <th>FO In Charge</th>
                      </tr>
                  </thead>

                  <tbody class="f-12">
                  @foreach($roomsIn as $ra)
                   @if($ra->transID == $t->id)
                                           
                   <tr>
                    <td colspan="6" style="border-bottom: 3px solid black;">
                       ROOM: {{$ra->roomNo.' - ('.$ra->roomType.')'}}
                    </td>
                  </tr>
                    
                  
         
                      @foreach($roomChargesAudit as $rc)
                      @if($rc->roomReservationId == $ra->roomReservationId)
                      <tr>
                        <td>{{$rc->os_id}}</td>
                        <td>{{$rc->item_name.' (Charged to: '.$rc->guestName.' - '.$rc->roomName.')'}}</td>
                        @if($rc->account_type == 1)
                          <td style="text-align:right;">{{number_format($rc->price,2)}}</td>
                          <td></td>
                          <?php $totalCharges+=$rc->price; ?>
                        @elseif($rc->account_type == 2)
                          <td></td>
                          <td style="text-align:right;">{{number_format($rc->price,2)}}</td>
                          <?php $totalPayments+=$rc->price; ?>
                        @endif
                        <td>{{$rc->chargeType}}</td>
                        <td>{{$rc->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach

                      @foreach($downpayments as $d)
                      @if($d->roomReservationId == $ra->roomReservationId)
                      <tr>
                        <td></td>
                        <td>{{$d->notes.' - '.$ra->roomNo.' ('.$ra->roomType.')'}}</td>
                        <td></td>
                        <td style="text-align:right;">{{number_format($d->amount,2)}}<?php $totalPayments+=$d->amount; ?></td>
                        <td>{{$d->chargeType}}</td>
                        <td>{{$d->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach
                  
   
                   @endif
                  @endforeach
                   
                      @foreach($downpayments as $d)
                      @if($d->transID == $t->id and $d->roomReservationId == 0)
                      <tr>
                        <td></td>
                        <td>{{$d->notes}}</td>
                        <td></td>
                        <td style="text-align:right;">{{number_format($d->amount,2)}}<?php $totalPayments+=$d->amount; ?></td>
                        <td>{{$d->chargeType}}</td>
                        <td>{{$d->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach
               

                    <tr>
                        <td style="text-align:right;" colspan="2"><strong>TOTAL:</strong></td>
                        <td style="text-align:right;"><strong>{{number_format($totalCharges,2)}}</strong></td>
                        <td style="text-align:right;"><strong>{{number_format($totalPayments,2)}}</strong></td>
                        <td></td>
                        <td></td>
                      </tr>
                    </tbody>






               
                </table>

              <?php array_push($transactionsIDA, $t->id); ?>
                  @endif
                @endforeach

            </div>
              <div class="panel-footer bg-light">
            &nbsp;
              </div>
            </div>
        </div>
                
        
                
                   
              <div class="tab-pane" id="tab5_2">
                              
<!--     STAYING-->
                <div class="panel">
                  <div class="panel-header bg-dark">
                    <h3><strong>Reservations:</strong></h3>
             
                  </div>

                  <div class="panel-content" style="overflow-y: scroll; height:500px;">
                         @foreach($transactions as $t)
                  @if($t->arrivalDate < $dateMain and $t->depatureDate > $dateMain and !in_array($t->id,$transactionsIDS))
                    <?php $totalCharges = 0;
                          $totalPayments = 0;

                     ?>

           
                <table id="transactionTables" class="table table-bordered bg-white">
            
                  <thead class="f-13 bg-dark">
                    <tr>
                      <th colspan="3" class="bg-blue">Code: <strong>{{$t->code}}</strong></th>
                      <th colspan="2" class="bg-blue">Rooms:</th>
                      <th class="bg-blue">Status:</th>
                    </tr>
                  </thead>
                  <tbody class="f-12">
                    <tr>
                      <td colspan="3">
                        <ul style="list-style: none;">
                          <li>Institution: <strong>{{$t->institutionName.' ('.$t->accountName}})</strong></li>
                          <li>Booking Person: <strong>{{$t->bookingPerson}}</strong></li>
                        </ul>
                        
                      </td>
                      <td colspan="2" valign="top">
                        <ul style="margin-left:20px;">
                          @foreach($roomsIn as $ra)
                          @if($ra->transID == $t->id)
                              <li>{{$ra->roomNo.' ('.$ra->roomType}})</li>
                          @endif
                          @endforeach
                        </ul>
                         
                      </td>
                      <td>
                        <ul style="list-style: none;">
                        @if($t->transactionStatus == 0)
                          <li><span class="label label-success">Ongoing</span></li>
                        @elseif($t->transactionStatus ==1)
                          <li><span class="label label-danger">Billed</span></li>
                        @elseif($t->transactionStatus == 2)
                          <li><span class="label label-dark">No Show</span></li>
                        @elseif($t->transactionStatus == 3)
                          <li><span class="label label-blue">House Use</span></li>
                        @elseif($t->transactionStatus == 100)
                          <li><span class="label label-danger">Fully Paid</span></li>
                        @elseif($t->transactionStatus == 1000)
                          <li><span class="label label-dark">Partial Payment</span></li>
                        @endif


                        @if($t->guaranteed == 1)
                          <li><span class="label label-warning">Guaranteed</span></li>
                        @elseif($t->guaranteed == 2)
                          <li><span class="label label-default">Not Guaranteed</span></li>
                        @endif 
                        </ul>
                      </td>
                    </tr>
                  </tbody>
                <thead class="f-12">
                      <tr>
                        <th>OS/OR No.</th>
                        <th>Particulars</th>
                        <th>Charges</th>
                        <th>Payments</th>
                        <th>Paid thru</th>
                        <th>FO In Charge</th>
                      </tr>
                  </thead>

                  <tbody class="f-12">
                  @foreach($roomsIn as $ra)
                   @if($ra->transID == $t->id)
                                           
                   <tr>
                    <td colspan="6" style="border-bottom: 3px solid black;">
                       ROOM: {{$ra->roomNo.' - ('.$ra->roomType.')'}}
                    </td>
                  </tr>
                    
                  
         
                      @foreach($roomChargesAudit as $rc)
                      @if($rc->roomReservationId == $ra->roomReservationId)
                      <tr>
                        <td>{{$rc->os_id}}</td>
                        <td>{{$rc->item_name.' (Charged to: '.$rc->guestName.' - '.$rc->roomName.')'}}</td>
                        @if($rc->account_type == 1)
                          <td style="text-align:right;">{{number_format($rc->price,2)}}</td>
                          <td></td>
                          <?php $totalCharges+=$rc->price; ?>
                        @elseif($rc->account_type == 2)
                          <td></td>
                          <td style="text-align:right;">{{number_format($rc->price,2)}}</td>
                          <?php $totalPayments+=$rc->price; ?>
                        @endif
                        <td>{{$rc->chargeType}}</td>
                        <td>{{$rc->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach

                      @foreach($downpayments as $d)
                      @if($d->roomReservationId == $ra->roomReservationId)
                      <tr>
                        <td></td>
                        <td>{{$d->notes.' - '.$ra->roomNo.' ('.$ra->roomType.')'}}</td>
                        <td></td>
                        <td style="text-align:right;">{{number_format($d->amount,2)}}<?php $totalPayments+=$d->amount; ?></td>
                        <td>{{$d->chargeType}}</td>
                        <td>{{$d->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach
                  
                    
            
               
                   
                
                   @endif
                  @endforeach


                      @foreach($downpayments as $d)
                      @if($d->transID == $t->id and $d->roomReservationId == 0)
                      <tr>
                        <td></td>
                        <td>{{$d->notes}}</td>
                        <td></td>
                        <td style="text-align:right;">{{number_format($d->amount,2)}}<?php $totalPayments+=$d->amount; ?></td>
                        <td>{{$d->chargeType}}</td>
                        <td>{{$d->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach
              
                   
                    <tr>
                        <td style="text-align:right;" colspan="2"><strong>TOTAL:</strong></td>
                        <td style="text-align:right;"><strong>{{number_format($totalCharges,2)}}</strong></td>
                        <td style="text-align:right;"><strong>{{number_format($totalPayments,2)}}</strong></td>
                        <td></td>
                        <td></td>
                      </tr>
                    </tbody>






               
                </table>

            <?php array_push($transactionsIDS, $t->id); ?>
                  @endif
                @endforeach

            </div>
              <div class="panel-footer bg-light">
            &nbsp;
              </div>
            </div>
 

                       
              </div>
              <div class="tab-pane" id="tab5_3">
                        <div class="panel">
                  <div class="panel-header bg-dark">
                    <h3><strong>Reservations:</strong></h3>
             
                  </div>

                  <div class="panel-content" style="overflow-y: scroll; height:500px;">
                         @foreach($transactions as $t)
                  @if($t->depatureDate == $dateMain and !in_array($t->id,$transactionsIDD))
                    <?php $totalCharges = 0;
                          $totalPayments = 0;

                     ?>

           
                <table id="transactionTables" class="table table-bordered bg-white">
            
                  <thead class="f-13 bg-dark">
                    <tr>
                      <th colspan="3" class="bg-blue">Code: <strong>{{$t->code}}</strong></th>
                      <th colspan="2" class="bg-blue">Rooms:</th>
                      <th class="bg-blue">Status:</th>
                    </tr>
                  </thead>
                  <tbody class="f-12">
                    <tr>
                      <td colspan="3">
                        <ul style="list-style: none;">
                          <li>Institution: <strong>{{$t->institutionName.' ('.$t->accountName}})</strong></li>
                          <li>Booking Person: <strong>{{$t->bookingPerson}}</strong></li>
                        </ul>
                        
                      </td>
                      <td colspan="2" valign="top">
                        <ul style="margin-left:20px;">
                          @foreach($roomsIn as $ra)
                          @if($ra->transID == $t->id)
                              <li>{{$ra->roomNo.' ('.$ra->roomType}})</li>
                          @endif
                          @endforeach
                        </ul>
                         
                      </td>
                      <td>
                        <ul style="list-style: none;">
                        @if($t->transactionStatus == 0)
                          <li><span class="label label-success">Ongoing</span></li>
                        @elseif($t->transactionStatus ==1)
                          <li><span class="label label-danger">Billed</span></li>
                        @elseif($t->transactionStatus == 2)
                          <li><span class="label label-dark">No Show</span></li>
                        @elseif($t->transactionStatus == 3)
                          <li><span class="label label-blue">House Use</span></li>
                        @elseif($t->transactionStatus == 100)
                          <li><span class="label label-danger">Fully Paid</span></li>
                        @elseif($t->transactionStatus == 1000)
                          <li><span class="label label-dark">Partial Payment</span></li>
                        @endif


                        @if($t->guaranteed == 1)
                          <li><span class="label label-warning">Guaranteed</span></li>
                        @elseif($t->guaranteed == 2)
                          <li><span class="label label-default">Not Guaranteed</span></li>
                        @endif 
                        </ul>
                      </td>
                    </tr>
                  </tbody>
                <thead class="f-12">
                      <tr>
                        <th>OS/OR No.</th>
                        <th>Particulars</th>
                        <th>Charges</th>
                        <th>Payments</th>
                        <th>Paid thru</th>
                        <th>FO In Charge</th>
                      </tr>
                  </thead>

                  <tbody class="f-12">
                  @foreach($roomsIn as $ra)
                   @if($ra->transID == $t->id)
                                           
                   <tr>
                    <td colspan="6" style="border-bottom: 3px solid black;">
                       ROOM: {{$ra->roomNo.' - ('.$ra->roomType.')'}}
                    </td>
                  </tr>
                    
                  
         
                      @foreach($roomChargesAudit as $rc)
                      @if($rc->roomReservationId == $ra->roomReservationId)
                      <tr>
                        <td>{{$rc->os_id}}</td>
                        <td>{{$rc->item_name.' (Charged to: '.$rc->guestName.' - '.$rc->roomName.')'}}</td>
                        @if($rc->account_type == 1)
                          <td style="text-align:right;">{{number_format($rc->price,2)}}</td>
                          <td></td>
                          <?php $totalCharges+=$rc->price; ?>
                        @elseif($rc->account_type == 2)
                          <td></td>
                          <td style="text-align:right;">{{number_format($rc->price,2)}}</td>
                          <?php $totalPayments+=$rc->price; ?>
                        @endif
                        <td>{{$rc->chargeType}}</td>
                        <td>{{$rc->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach

                      @foreach($downpayments as $d)
                      @if($d->roomReservationId == $ra->roomReservationId)
                      <tr>
                        <td></td>
                        <td>{{$d->notes.' - '.$ra->roomNo.' ('.$ra->roomType.')'}}</td>
                        <td></td>
                        <td style="text-align:right;">{{number_format($d->amount,2)}}<?php $totalPayments+=$d->amount; ?></td>
                        <td>{{$d->chargeType}}</td>
                        <td>{{$d->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach
                  
                    
            
               
                   
                   
                 
                     
                
                   @endif
                  @endforeach
                      @foreach($downpayments as $d)
                      @if($d->transID == $t->id and $d->roomReservationId == 0)
                      <tr>
                        <td></td>
                        <td>{{$d->notes}}</td>
                        <td></td>
                        <td style="text-align:right;">{{number_format($d->amount,2)}}<?php $totalPayments+=$d->amount; ?></td>
                        <td>{{$d->chargeType}}</td>
                        <td>{{$d->foInCharge}}</td>
                      </tr>
                      @endif
                      @endforeach
                    <tr>
                        <td style="text-align:right;" colspan="2"><strong>TOTAL:</strong></td>
                        <td style="text-align:right;"><strong>{{number_format($totalCharges,2)}}</strong></td>
                        <td style="text-align:right;"><strong>{{number_format($totalPayments,2)}}</strong></td>
                        <td></td>
                        <td></td>
                      </tr>
                    </tbody>






               
                </table>
                <?php array_push($transactionsIDD, $t->id); ?>
            
                  @endif
                @endforeach

            </div>
              <div class="panel-footer bg-light">
            &nbsp;
              </div>
            </div>
                     
              </div>
                        
          </div>
           </div>
          </div>
          </div><br/>
          <div class="row">
               <div class="col-md-12">
                         
                            <div class="row">
                                <div class="col-md-6">
                                    <?php $percentage = ($totalRooms/41)*100; ?>
                                    <h5 style="font-weight:bold;">Occupancy Rate:</h5> <h2>{{$totalRooms}}/41 ({{sprintf("%.0f%%",$percentage)}})</h2>
                                        
                                            <div class="progress progress-bar-large" style="width:60%;">
                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="100" style="width: {{$percentage}}%">
                         
                        </div>
                      </div>
                      </div>
                      </div>
                      </div>
          </div>

          <div class="row">
            <div class="col-md-4">
              <a class="btn btn-default btn-embossed" href="{{route('frontdesk.printRoomStatusReport')}}">Generate Room Status Report</a>
            </div>
          </div><hr/>
          <div class="row">
            <div class="col-md-4">
              <h5><strong>Daily Room and Guest Count Report</strong></h5>

               <a class="btn btn-default btn-embossed" href="{{route('frontdesk.printDailyRoomGuestCount')}}">Generate Room and Guest Report</a>

            </div>
          </div>
                
       <br/>

                
                </div>
               </div>
          
          <hr/>
         
          <!-- BEGIN MODALS -->
          <div class="modal fade" id="modal-basic" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>ROOM</strong> STATUS</h4>
                </div>
                <div class="modal-body">
                  My content...<br>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-embossed" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary btn-embossed" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Large width</strong> modal</h4>
                </div>
                <div class="modal-body">
                  My content...
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-embossed" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary btn-embossed" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade" id="modal-full" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-full">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Fullwidth</strong> modal</h4>
                </div>
                <div class="modal-body">
                  Resize your window to see fullwidth resizing.
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-embossed" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary btn-embossed" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade" id="modal-responsive" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Responsive</strong> modal</h4>
                </div>
                <div class="modal-body">
                  <p>Change screen size to see responsive behaviour.</p>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="field-1" class="control-label">Name</label>
                        <input type="text" class="form-control" id="field-1" placeholder="Steve">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="field-2" class="control-label">Surname</label>
                        <input type="text" class="form-control" id="field-2" placeholder="Winston">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label for="field-3" class="control-label">Address</label>
                        <input type="text" class="form-control" id="field-3" placeholder="Address">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="field-4" class="control-label">City</label>
                        <input type="text" class="form-control" id="field-4" placeholder="New York">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="field-5" class="control-label">Country</label>
                        <input type="text" class="form-control" id="field-5" placeholder="USA">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="field-6" class="control-label">Zip</label>
                        <input type="text" class="form-control" id="field-6" placeholder="24587">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer text-center">
                  <button type="button" class="btn btn-primary btn-embossed bnt-square" data-dismiss="modal"><i class="fa fa-check"></i> Validate</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade modal-topfull" id="modal-topfull" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-topfull">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Top Fullwidth</strong> modal</h4>
                </div>
                <div class="modal-body">
                  My content...
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-embossed" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary btn-embossed" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade modal-bottomfull" id="modal-bottomfull" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Bottom Fullwidth</strong> modal</h4>
                </div>
                <div class="modal-body">
                  My content...
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-embossed" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary btn-embossed" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade modal-slideright" id="modal-slideright" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-body">
                  <div class="row">
                    <div class="col-md-12">
                      <h2 class="c-primary m-b-30">Are you sure you want to proceed?</h2>
                      <button type="button" class="btn btn-primary btn-embossed btn-block" data-dismiss="modal">Yes, I'm sure</button>
                      <button type="button" data-dismiss="modal" class="btn btn-white btn-block">Oops, I prefer not!</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade modal-slideleft" id="modal-slideleft" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-body">
                  <div class="row">
                    <div class="col-md-12">
                      <h2 class="c-primary m-b-30">Are you sure you want to proceed?</h2>
                      <button type="button" class="btn btn-primary btn-embossed btn-block" data-dismiss="modal">Yes, I'm sure</button>
                      <button type="button" data-dismiss="modal" class="btn btn-white btn-block">Oops, I prefer not!</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade modal-image" id="modal-image" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                </div>
                <div class="modal-body">
                  <img src=" assets/global/images/gallery/transport3.jpg" alt="picture 1" class="img-responsive">
                </div>
                <div class="modal-footer">
                  <p>Title of your image</p>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade" id="colored-header" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header bg-primary">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Colored</strong> Header</h4>
                </div>
                <div class="modal-body">
                  <p>Want colors? Click on a color to switch header look:</p>
                  <div class="p-t-20 m-b-20 p-l-40">
                    <ul class="colors-list color-header">
                      <li class="dark"></li>
                      <li class="red"></li>
                      <li class="green"></li>
                      <li class="blue active"></li>
                      <li class="aero"></li>
                      <li class="gray"></li>
                      <li class="orange"></li>
                      <li class="pink"></li>
                      <li class="purple"></li>
                    </ul>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-embossed" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary btn-embossed" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade" id="modal-footer" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title"><strong>Colored</strong> Footer</h4>
                </div>
                <div class="modal-body">
                  <p class="m-t-40">Like for header, you can add colors. Click on a color to switch header look:</p>
                  <div class="p-t-20 m-b-20 p-l-40">
                    <ul class="colors-list color-footer">
                      <li class="dark active"></li>
                      <li class="red"></li>
                      <li class="green"></li>
                      <li class="gray-light"></li>
                      <li class="blue"></li>
                      <li class="aero"></li>
                      <li class="gray"></li>
                      <li class="orange"></li>
                      <li class="pink"></li>
                      <li class="purple"></li>
                    </ul>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-dark" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <div class="modal fade" id="full-colored" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content bg-primary">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="icons-office-52"></i></button>
                  <h4 class="modal-title">Full <strong>Colored</strong></h4>
                </div>
                <div class="modal-body">
                  <p class="m-t-40">Like for header, you can add colors. Click on a color to switch header look:</p>
                  <div class="p-t-20 m-b-20 p-l-40">
                    <ul class="colors-list color-full">
                      <li class="dark active"></li>
                      <li class="red"></li>
                      <li class="green"></li>
                      <li class="gray-light"></li>
                      <li class="blue"></li>
                      <li class="aero"></li>
                      <li class="gray"></li>
                      <li class="orange"></li>
                      <li class="pink"></li>
                      <li class="purple"></li>
                    </ul>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-dark" data-dismiss="modal">Save changes</button>
                </div>
              </div>
            </div>
          </div>
          <!-- END MODALS -->
          <div class="footer">
            <div class="copyright">
              <p class="pull-left sm-pull-reset">
                <span>Copyright <span class="copyright">©</span> 2015 </span>
                <span>THEMES LAB</span>.
                <span>All rights reserved. </span>
              </p>
              <p class="pull-right sm-pull-reset">
                <span><a href="#" class="m-r-10">Support</a> | <a href="#" class="m-l-10 m-r-10">Terms of use</a> | <a href="#" class="m-l-10">Privacy Policy</a></span>
              </p>
            </div>
          </div>
        </div>
        <!-- END PAGE CONTENT -->
      </div>




@endsection